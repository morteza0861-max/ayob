'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { weddingConfig as cfg } from '@/config/wedding';

/**
 * 🎵 هوک مدیریت موسیقی جشن
 *
 * ▸ پخش فقط با تعامل کاربر آغاز می‌شود (کلیک روی «ورود به جشن»).
 * ▸ اگر منبع اول در دسترس نباشد، به‌صورت خودکار منبع بعدی امتحان می‌شود.
 * ▸ فایل صوتی در سطح صفحه اصلی نگه داشته می‌شود و با جابه‌جایی بین بخش‌های
 *   سایت هرگز قطع نمی‌شود (عنصر audio در کامپوننت ریشه رندر می‌شود).
 */
export function useWeddingMusic() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const sourceIndexRef = useRef(0);
  const wantPlayRef = useRef(false);

  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(false);
  const [started, setStarted] = useState(false);

  /* ساخت عنصر audio (یک‌بار برای همیشه) */
  useEffect(() => {
    const audio = new Audio();
    audio.loop = true;
    audio.preload = 'auto';
    audio.volume = cfg.music.volume;
    audioRef.current = audio;

    const onPlaying = () => {
      setIsPlaying(true);
      setIsLoading(false);
      setError(false);
    };
    const onPause = () => setIsPlaying(false);
    const onWaiting = () => setIsLoading(true);
    const onCanPlay = () => setIsLoading(false);
    const onError = () => {
      // تلاش برای منبع بعدی (fallback)
      const next = sourceIndexRef.current + 1;
      if (next < cfg.music.sources.length) {
        sourceIndexRef.current = next;
        audio.src = cfg.music.sources[next];
        audio.load();
        if (wantPlayRef.current) {
          audio.play().catch(() => {
            setIsLoading(false);
            setError(true);
            setIsPlaying(false);
          });
        }
      } else {
        setIsLoading(false);
        setIsPlaying(false);
        setError(true);
      }
    };

    audio.addEventListener('playing', onPlaying);
    audio.addEventListener('pause', onPause);
    audio.addEventListener('waiting', onWaiting);
    audio.addEventListener('canplay', onCanPlay);
    audio.addEventListener('error', onError);

    return () => {
      audio.pause();
      audio.removeEventListener('playing', onPlaying);
      audio.removeEventListener('pause', onPause);
      audio.removeEventListener('waiting', onWaiting);
      audio.removeEventListener('canplay', onCanPlay);
      audio.removeEventListener('error', onError);
      audio.src = '';
      audioRef.current = null;
    };
  }, []);

  /** آغاز پخش (باید مستقیماً در هندلر کلیک کاربر صدا زده شود) */
  const start = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    wantPlayRef.current = true;
    setStarted(true);
    setIsLoading(true);
    if (!audio.src) {
      audio.src = cfg.music.sources[sourceIndexRef.current];
      audio.load();
    }
    audio
      .play()
      .then(() => {
        setError(false);
      })
      .catch(() => {
        setIsLoading(false);
        setError(true);
      });
  }, []);

  /** روشن / خاموش کردن */
  const toggle = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (audio.paused) {
      wantPlayRef.current = true;
      setIsLoading(true);
      if (!audio.src) {
        audio.src = cfg.music.sources[sourceIndexRef.current];
        audio.load();
      }
      audio
        .play()
        .then(() => setError(false))
        .catch(() => {
          setIsLoading(false);
          setError(true);
        });
    } else {
      wantPlayRef.current = false;
      audio.pause();
      setIsLoading(false);
    }
  }, []);

  /** تلاش مجدد پس از خطا */
  const retry = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    sourceIndexRef.current = 0;
    wantPlayRef.current = true;
    setIsLoading(true);
    setError(false);
    audio.src = cfg.music.sources[0];
    audio.load();
    audio.play().catch(() => {
      setIsLoading(false);
      setError(true);
    });
  }, []);

  return { isPlaying, isLoading, error, started, start, toggle, retry };
}
