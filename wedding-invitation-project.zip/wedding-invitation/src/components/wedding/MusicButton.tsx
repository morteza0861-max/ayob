'use client';

/**
 * 🎛️ دکمه شناور روشن/خاموش موسیقی
 * با آیکون اکولایزر متحرک که فقط هنگام پخش، حرکت می‌کند.
 */

interface MusicButtonProps {
  isPlaying: boolean;
  isLoading: boolean;
  error: boolean;
  visible: boolean;
  onToggle: () => void;
  onRetry: () => void;
}

export default function MusicButton({
  isPlaying,
  isLoading,
  error,
  visible,
  onToggle,
  onRetry,
}: MusicButtonProps) {
  if (!visible) return null;

  return (
    <>
      <button
        type="button"
        onClick={error ? onRetry : onToggle}
        className={`music-btn ${isPlaying ? 'music-playing' : ''}`}
        aria-label={
          error
            ? 'تلاش مجدد برای پخش موسیقی'
            : isPlaying
              ? 'خاموش کردن موسیقی'
              : 'پخش موسیقی'
        }
        title={
          error
            ? 'موسیقی بارگذاری نشد — برای تلاش مجدد بزنید'
            : isPlaying
              ? 'خاموش کردن موسیقی'
              : 'پخش موسیقی'
        }
      >
        {/* اکولایزر متحرک */}
        <span className="eq-bars" aria-hidden="true">
          <span className="eq-bar" />
          <span className="eq-bar" />
          <span className="eq-bar" />
          <span className="eq-bar" />
        </span>
        {/* علامت خطا یا توقف */}
        {(error || (!isPlaying && !isLoading)) && (
          <span
            aria-hidden="true"
            className="absolute -left-0.5 -top-0.5 grid h-5 w-5 place-items-center rounded-full border border-[#d4af37] bg-white text-[0.6rem] shadow"
          >
            {error ? '⚠️' : '▶'}
          </span>
        )}
        {isLoading && (
          <span
            aria-hidden="true"
            className="absolute inset-0 animate-spin rounded-full border-2 border-transparent border-t-[#c9a227]"
            style={{ animationDuration: '1.1s' }}
          />
        )}
      </button>

      {/* برچسب ظریف کنار دکمه */}
      <span
        aria-hidden="true"
        className="pointer-events-none fixed bottom-[calc(1.35rem+env(safe-area-inset-bottom,0px))] right-[4.2rem] z-[59] hidden rounded-full bg-[#fffdf6]/85 px-3 py-1 text-[0.7rem] font-bold text-[#8a6a1f] shadow-sm backdrop-blur-sm sm:block"
      >
        موسیقی جشن
      </span>
    </>
  );
}
