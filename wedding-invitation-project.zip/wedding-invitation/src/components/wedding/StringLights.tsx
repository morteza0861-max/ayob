'use client';

import { useEffect, useMemo, useState } from 'react';

/**
 * 🎄 ریسه‌های نورانی جشن
 * سیم‌های آویزان با لامپ‌های رنگی که یکی‌پس‌ازدیگری روشن می‌شوند و سپس
 * به‌آرامی چشمک می‌زنند. موقعیت لامپ‌ها روی منحنی سیم (بزیه درجه۲) محاسبه
 * می‌شود تا کاملاً منطبق باشد.
 */

const BULB_COLORS = [
  '#ffb3c1', // صورتی
  '#ffd98a', // طلایی
  '#fff3d6', // سفید گرم
  '#f7a6bc', // رز
  '#ffe9a8', // کهربایی
] as const;

interface StringLightsProps {
  lit: boolean;
  /** تعداد ریسه (سیم) */
  wires?: number;
  /** تعداد لامپ در هر ریسه */
  bulbsPerWire?: number;
  className?: string;
}

export default function StringLights({
  lit,
  wires = 2,
  bulbsPerWire = 15,
  className = '',
}: StringLightsProps) {
  const [litNow, setLitNow] = useState(false);

  // پس از mounting روشن‌شدن ترتیبی را آغاز کن (برای انیمیشن transition)
  useEffect(() => {
    if (!lit) return;
    const id = window.setTimeout(() => setLitNow(true), 120);
    return () => window.clearTimeout(id);
  }, [lit]);

  // تأخیرهای ثابت و شبه‌تصادفی (بدون breaking hydration)
  const delays = useMemo(() => {
    const arr: { turnOn: number; twinkle: number }[] = [];
    for (let i = 0; i < bulbsPerWire * wires; i++) {
      const turnOn = i * 90 + ((i * 37) % 60);
      const twinkle = ((i * 137) % 2100) / 1000;
      arr.push({ turnOn, twinkle });
    }
    return arr;
  }, [bulbsPerWire, wires]);

  const wireConfigs = useMemo(
    () =>
      Array.from({ length: wires }, (_, w) => ({
        top: 14 + w * 46, // فاصله عمودی هر ریسه
        sag: 34 + (w % 2) * 12, // عمق افتادگی سیم
        offset: w % 2 === 0 ? 0 : 30, // جابه‌جایی افقی الگو
      })),
    [wires]
  );

  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none absolute inset-x-0 top-0 z-20 select-none ${className}`}
    >
      {wireConfigs.map((cfg, w) => {
        const sagPct = cfg.sag;
        const pathD = `M 0 0 Q 50 ${sagPct * 2} 100 0`;
        return (
          <div
            key={w}
            className="absolute inset-x-0"
            style={{ top: cfg.top, height: sagPct + 26 }}
          >
            {/* سیم ریسه */}
            <svg
              className="absolute inset-0 h-full w-full"
              viewBox="0 0 100 100"
              preserveAspectRatio="none"
            >
              <path
                d={pathD}
                fill="none"
                stroke="rgba(70, 52, 30, 0.55)"
                strokeWidth="0.5"
                vectorEffect="non-scaling-stroke"
                style={{ transform: `translateY(${0}px)`, transformOrigin: 'center' }}
              />
            </svg>

            {/* لامپ‌ها */}
            {Array.from({ length: bulbsPerWire }, (_, i) => {
              const idx = w * bulbsPerWire + i;
              const t = (i + 0.5) / bulbsPerWire;
              // y روی بزیه: (1-t)²·y0 + 2(1-t)t·cy + t²·y1  →  با y0=y1=0
              const yPct = 2 * (1 - t) * t * sagPct * (100 / (sagPct + 26));
              const color = BULB_COLORS[idx % BULB_COLORS.length];
              return (
                <span
                  key={i}
                  className={`bulb ${litNow ? 'bulb-lit' : ''}`}
                  style={
                    {
                      left: `calc(${(t * 100).toFixed(2)}% )`,
                      top: `${yPct.toFixed(2)}%`,
                      '--bulb-color': color,
                      '--turn-on-delay': `${delays[idx]?.turnOn ?? 0}ms`,
                      '--twinkle-delay': `${delays[idx]?.twinkle ?? 0}s`,
                    } as React.CSSProperties
                  }
                />
              );
            })}
          </div>
        );
      })}
    </div>
  );
}
