'use client';

import { weddingConfig as cfg } from '@/config/wedding';

/**
 * 🎬 ترنزیشن سینمایی — باز شدن دروازه‌های گل‌آرایی‌شده
 * دو پرده ابریشمی کرم با لبه طلایی از وسط باز می‌شوند، قلب طلایی می‌درخشد،
 * نور طلایی فلاش می‌زند و صحنه جشن نمایان می‌شود.
 */
export default function CurtainTransition() {
  return (
    <div
      className="curtain-overlay curtain-opening"
      role="presentation"
      aria-hidden="true"
    >
      {/* پرده چپ */}
      <div className="curtain-panel curtain-left">
        <div
          className="absolute bottom-0 left-0 top-0 w-[9rem] opacity-80"
          style={{
            transform: 'scaleX(-1)',
            maskImage: 'linear-gradient(to left, black 30%, transparent 96%)',
            WebkitMaskImage:
              'linear-gradient(to left, black 30%, transparent 96%)',
          }}
        >
          <img
            src="/images/floral-garland.png"
            alt=""
            className="h-full w-full object-cover object-left mix-blend-multiply"
          />
        </div>
      </div>

      {/* پرده راست */}
      <div className="curtain-panel curtain-right">
        <div
          className="absolute bottom-0 right-0 top-0 w-[9rem] opacity-80"
          style={{
            maskImage: 'linear-gradient(to right, black 30%, transparent 96%)',
            WebkitMaskImage:
              'linear-gradient(to right, black 30%, transparent 96%)',
          }}
        >
          <img
            src="/images/floral-garland.png"
            alt=""
            className="h-full w-full object-cover object-right mix-blend-multiply"
          />
        </div>
      </div>

      {/* درخشش طلایی + قلب */}
      <div className="curtain-flash" />
      <div className="curtain-heart" aria-hidden="true">
        💛
      </div>

      {/* نام زوج در لحظه باز شدن */}
      <p
        className="font-nastaliq pointer-events-none absolute inset-x-0 top-[30%] z-[2] text-center text-[1.5rem] text-[#6b4f1d]"
        style={{ animation: 'curtainNames 1.6s ease 0.35s both' }}
      >
        {cfg.groom.full} {cfg.heart} {cfg.bride.full}
      </p>
    </div>
  );
}
