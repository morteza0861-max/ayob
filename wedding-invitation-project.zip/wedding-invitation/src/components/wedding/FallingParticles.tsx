'use client';

import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
} from 'react';

export type ParticlesHandle = {
  /** انفجار ظریف گلبرگ و قلب در یک نقطه (مختصات پنجره) */
  burst: (x: number, y: number, count?: number) => void;
};

type Mode = 'card' | 'celebration';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  rot: number;
  vr: number;
  swayAmp: number;
  swayFreq: number;
  swayPhase: number;
  alpha: number;
  kind: 0 | 1 | 2; // 0 گلبرگ | 1 قلب طلایی | 2 ذره نورانی
  spriteIndex: number;
  temp?: boolean;
}

/* ---------- ساخت اسپرایت‌ها (یک‌بار، خارج از حلقه انیمیشن) ---------- */

function makePetalSprite(color: string, inner: string): HTMLCanvasElement {
  const s = 64;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(s / 2, s / 2, 4, s / 2, s / 2, s / 2);
  g.addColorStop(0, inner);
  g.addColorStop(1, color);
  ctx.fillStyle = g;
  ctx.beginPath();
  // شکل گلبرگ رز (بیضی کشیده با نوک ظریف)
  ctx.moveTo(s / 2, 4);
  ctx.bezierCurveTo(s * 0.86, s * 0.22, s * 0.9, s * 0.68, s / 2, s - 4);
  ctx.bezierCurveTo(s * 0.1, s * 0.68, s * 0.14, s * 0.22, s / 2, 4);
  ctx.closePath();
  ctx.fill();
  // رگه ظریف مرکز گلبرگ
  ctx.strokeStyle = 'rgba(255,255,255,0.35)';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(s / 2, s * 0.2);
  ctx.quadraticCurveTo(s * 0.56, s * 0.5, s / 2, s * 0.82);
  ctx.stroke();
  return c;
}

function makeHeartSprite(color: string, glow: string): HTMLCanvasElement {
  const s = 64;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  ctx.shadowColor = glow;
  ctx.shadowBlur = 10;
  ctx.fillStyle = color;
  ctx.beginPath();
  const t = s * 0.16;
  ctx.moveTo(s / 2, s - t);
  ctx.bezierCurveTo(-s * 0.08, s * 0.62, s * 0.16, s * 0.16, s / 2, s * 0.38);
  ctx.bezierCurveTo(s * 0.84, s * 0.16, s * 1.08, s * 0.62, s / 2, s - t);
  ctx.closePath();
  ctx.fill();
  return c;
}

function makeSparkSprite(color: string): HTMLCanvasElement {
  const s = 48;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  g.addColorStop(0, color);
  g.addColorStop(0.35, color);
  g.addColorStop(1, 'rgba(255, 240, 190, 0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, s, s);
  return c;
}

interface FallingParticlesProps {
  mode: Mode;
  reduced?: boolean;
}

function targetCounts(m: Mode) {
  const small = window.innerWidth < 640;
  if (m === 'card') {
    return small
      ? { petals: 11, sparks: 6, hearts: 3, total: 20 }
      : { petals: 16, sparks: 9, hearts: 4, total: 29 };
  }
  return small
    ? { petals: 15, sparks: 10, hearts: 5, total: 30 }
    : { petals: 22, sparks: 14, hearts: 7, total: 43 };
}

const FallingParticles = forwardRef<ParticlesHandle, FallingParticlesProps>(
  function FallingParticles({ mode, reduced = false }, ref) {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const spritesRef = useRef<HTMLCanvasElement[][]>([]);
    const particlesRef = useRef<Particle[]>([]);
    const rafRef = useRef(0);
    const runningRef = useRef(true);
    const modeRef = useRef<Mode>(mode);

    useImperativeHandle(ref, () => ({
      burst(x, y, count = 14) {
        const list = particlesRef.current;
        for (let i = 0; i < count; i++) {
          const ang = Math.random() * Math.PI * 2;
          const spd = 1.4 + Math.random() * 3.2;
          list.push({
            x,
            y,
            vx: Math.cos(ang) * spd,
            vy: Math.sin(ang) * spd - 1.6,
            size: 0.5 + Math.random() * 0.7,
            rot: Math.random() * Math.PI * 2,
            vr: (Math.random() - 0.5) * 0.22,
            swayAmp: 0.4 + Math.random() * 0.8,
            swayFreq: 0.014 + Math.random() * 0.02,
            swayPhase: Math.random() * Math.PI * 2,
            alpha: 1,
            kind: Math.random() < 0.42 ? 1 : Math.random() < 0.75 ? 0 : 2,
            spriteIndex: Math.floor(Math.random() * 3),
            temp: true,
          });
        }
        if (list.length > 220) list.splice(0, list.length - 220);
      },
    }));

    useEffect(() => {
      modeRef.current = mode;
      // تغییر آرام تعداد ذرات بین دو صحنه
      const list = particlesRef.current;
      const target = targetCounts(mode);
      list.length = Math.min(list.length, target.total);
    }, [mode]);

    useEffect(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d', { alpha: true });
      if (!ctx) return;

      /* اسپرایت‌ها */
      const petals = [
        makePetalSprite('rgba(244, 165, 174, 0.92)', 'rgba(255, 228, 232, 0.95)'),
        makePetalSprite('rgba(232, 121, 143, 0.9)', 'rgba(255, 214, 222, 0.95)'),
        makePetalSprite('rgba(255, 250, 244, 0.95)', 'rgba(255, 255, 255, 1)'),
      ];
      const hearts = [
        makeHeartSprite('rgba(212, 175, 55, 0.95)', 'rgba(246, 206, 106, 0.8)'),
        makeHeartSprite('rgba(232, 121, 143, 0.92)', 'rgba(249, 200, 212, 0.75)'),
        makeHeartSprite('rgba(255, 241, 189, 0.95)', 'rgba(255, 236, 160, 0.85)'),
      ];
      const sparks = [
        makeSparkSprite('rgba(255, 226, 130, 0.95)'),
        makeSparkSprite('rgba(255, 245, 214, 0.95)'),
        makeSparkSprite('rgba(255, 176, 196, 0.9)'),
      ];
      spritesRef.current = [petals, hearts, sparks];

      /* اندازه بوم */
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      let W = 0;
      let H = 0;
      const resize = () => {
        W = window.innerWidth;
        H = window.innerHeight;
        canvas.width = Math.floor(W * dpr);
        canvas.height = Math.floor(H * dpr);
        canvas.style.width = `${W}px`;
        canvas.style.height = `${H}px`;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      };
      resize();

      const spawn = (initial = false) => {
        const counts = targetCounts(modeRef.current);
        const list = particlesRef.current;
        list.length = 0;
        const make = (
          kind: 0 | 1 | 2,
          si: number,
          yOverride?: number
        ): Particle => ({
          x: Math.random() * W,
          y: yOverride ?? Math.random() * H,
          vx: 0,
          vy: kind === 2 ? 0.12 + Math.random() * 0.3 : 0.35 + Math.random() * 0.75,
          size:
            kind === 2
              ? 0.35 + Math.random() * 0.6
              : kind === 1
                ? 0.3 + Math.random() * 0.45
                : 0.42 + Math.random() * 0.55,
          rot: Math.random() * Math.PI * 2,
          vr: (Math.random() - 0.5) * 0.02,
          swayAmp: kind === 2 ? 0.3 : 0.8 + Math.random() * 1.5,
          swayFreq: 0.008 + Math.random() * 0.014,
          swayPhase: Math.random() * Math.PI * 2,
          alpha: kind === 2 ? 0.5 + Math.random() * 0.5 : 0.7 + Math.random() * 0.3,
          kind,
          spriteIndex: si,
        });
        for (let i = 0; i < counts.petals; i++)
          list.push(make(0, i % petals.length, initial ? undefined : -20 - Math.random() * 60));
        for (let i = 0; i < counts.hearts; i++)
          list.push(make(1, i % hearts.length, initial ? undefined : -20 - Math.random() * 120));
        for (let i = 0; i < counts.sparks; i++)
          list.push(make(2, i % sparks.length, initial ? undefined : Math.random() * H));
      };

      spawn(true);

      const onVisibility = () => {
        runningRef.current = !document.hidden;
        if (runningRef.current) rafRef.current = requestAnimationFrame(tick);
      };

      const reducedMotion = reduced;

      let t = 0;
      const tick = () => {
        if (!runningRef.current) return;
        t += 1;
        ctx.clearRect(0, 0, W, H);
        const sprites = spritesRef.current;
        const list = particlesRef.current;

        for (let i = list.length - 1; i >= 0; i--) {
          const p = list[i];
          const sway = Math.sin(t * p.swayFreq + p.swayPhase) * p.swayAmp;

          p.x += p.vx + sway * 0.35;
          p.y += p.vy;
          p.rot += p.vr;

          if (p.temp) {
            p.vy += 0.045; // جاذبه ملایم برای ذرات انفجاری
            p.vx *= 0.985;
            p.alpha -= 0.008;
            if (p.alpha <= 0.02) {
              list.splice(i, 1);
              continue;
            }
          }

          // بازچرخش از بالای صفحه
          const margin = 60;
          if (p.y > H + margin && !p.temp) {
            p.y = -margin;
            p.x = Math.random() * W;
          }
          if (p.x < -margin) p.x = W + margin;
          else if (p.x > W + margin) p.x = -margin;

          const spriteSet =
            p.kind === 0 ? sprites[0] : p.kind === 1 ? sprites[1] : sprites[2];
          const sprite = spriteSet[p.spriteIndex % spriteSet.length];
          const base = sprite.width;
          const scale = p.size * 0.62;
          const w = base * scale;
          const h = base * scale;

          ctx.save();
          ctx.globalAlpha = Math.max(0, Math.min(1, p.alpha));
          if (p.kind !== 2) {
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rot + sway * 0.06);
            ctx.drawImage(sprite, -w / 2, -h / 2, w, h);
          } else {
            // ذرات نورانی: درخشش نبض‌دار
            const pulse = 0.75 + Math.sin(t * 0.05 + p.swayPhase) * 0.25;
            ctx.globalAlpha *= pulse;
            ctx.drawImage(sprite, p.x - w / 2, p.y - h / 2, w, h);
          }
          ctx.restore();
        }

        rafRef.current = requestAnimationFrame(tick);
      };

      if (!reducedMotion) {
        rafRef.current = requestAnimationFrame(tick);
        document.addEventListener('visibilitychange', onVisibility);
      }
      window.addEventListener('resize', resize);

      return () => {
        cancelAnimationFrame(rafRef.current);
        document.removeEventListener('visibilitychange', onVisibility);
        window.removeEventListener('resize', resize);
      };
    }, [reduced]);

    return (
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-[35]"
      />
    );
  }
);

export default FallingParticles;
