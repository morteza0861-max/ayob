'use client';

import { useRef } from 'react';
import Image from 'next/image';
import { weddingConfig as cfg } from '@/config/wedding';
import StringLights from './StringLights';
import { downloadCalendarInvite } from '@/lib/calendar';
import { shareInvite } from '@/lib/share';
import type { ParticlesHandle } from './FallingParticles';

/**
 * 🎊 صحنه دوم — فضای جشن عروسی و چراغونی
 * تالار لوکس با نورپردازی سینمایی، ریسه‌های رنگارنگ، لوسترهای درخشان و
 * طاق گل‌آرایی‌شده + بخش پایانی با نام عروس و داماد.
 */

interface CelebrationSceneProps {
  particlesRef: React.RefObject<ParticlesHandle | null>;
  showToast: (text: string) => void;
}

export default function CelebrationScene({
  particlesRef,
  showToast,
}: CelebrationSceneProps) {
  const sceneRef = useRef<HTMLElement>(null);

  /* 📍 مسیریابی با برنامه نشان */
  const openNavigation = () => {
    window.open(cfg.map.neshanUrl, '_blank', 'noopener,noreferrer');
  };

  /* 📅 افزودن به تقویم */
  const addToCalendar = () => {
    downloadCalendarInvite(cfg);
    showToast('📅 فایل تقویم ذخیره شد؛ آن را باز کنید و رویداد را تأیید کنید.');
  };

  /* 💌 اشتراک‌گذاری دعوت‌نامه */
  const handleShare = async () => {
    const result = await shareInvite(cfg);
    if (result === 'shared') showToast('💌 دعوت‌نامه به اشتراک گذاشته شد!');
    else if (result === 'copied')
      showToast('🔗 لینک دعوت‌نامه کپی شد؛ برای مهمانان بفرستید.');
  };

  /* ✨ ضربان قلب با لمس صحنه (گلبرگ و قلب در نقطه لمس) */
  const handleSceneTap = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('button, a')) return;
    particlesRef.current?.burst(e.clientX, e.clientY, 16);
  };

  return (
    <>
      {/* ═══════════ صحنه اصلی جشن ═══════════ */}
      <section
        ref={sceneRef}
        onClick={handleSceneTap}
        aria-label="فضای جشن عروسی"
        className="scene-enter relative min-h-[100dvh] overflow-hidden bg-[#1c1013]"
      >
        {/* 🏛️ تصویر تالار لوکس */}
        <div className="absolute inset-0">
          <Image
            src="/images/hall-bg.jpg"
            alt="تالار مجلل عروسی با طاق گل‌آرایی‌شده رزهای صورتی و سفید، لوستر کریستالی و ریسه‌های نورانی"
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
          {/* سایه‌روشن سینمایی برای خوانایی */}
          <div
            className="absolute inset-0"
            style={{
              background:
                'linear-gradient(180deg, rgba(24,10,16,0.78) 0%, rgba(30,12,20,0.42) 26%, rgba(26,10,18,0.28) 48%, rgba(22,9,15,0.6) 78%, rgba(20,8,14,0.92) 100%)',
            }}
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                'radial-gradient(120% 70% at 50% 0%, transparent 40%, rgba(20,8,14,0.5) 100%)',
            }}
          />
        </div>

        {/* 💡 درخشش لوسترها و نورهای محیطی (طلایی، صورتی، سفید) */}
        <div aria-hidden="true" className="absolute inset-0 z-10">
          <div
            className="glow-blob left-1/2 top-[-6rem] h-64 w-64 -translate-x-1/2"
            style={{
              background:
                'radial-gradient(circle, rgba(255,226,130,0.55), transparent 70%)',
            }}
          />
          <div
            className="glow-blob left-[8%] top-[16%] h-40 w-40"
            style={{
              background:
                'radial-gradient(circle, rgba(255,179,193,0.4), transparent 70%)',
              animationDelay: '1.2s',
            }}
          />
          <div
            className="glow-blob right-[8%] top-[14%] h-44 w-44"
            style={{
              background:
                'radial-gradient(circle, rgba(255,243,214,0.42), transparent 70%)',
              animationDelay: '2.3s',
            }}
          />
          <div
            className="glow-blob bottom-[18%] left-[14%] h-52 w-52"
            style={{
              background:
                'radial-gradient(circle, rgba(246,206,106,0.3), transparent 70%)',
              animationDelay: '0.6s',
            }}
          />
          <div
            className="glow-blob bottom-[24%] right-[12%] h-48 w-48"
            style={{
              background:
                'radial-gradient(circle, rgba(255,183,197,0.28), transparent 70%)',
              animationDelay: '1.8s',
            }}
          />
        </div>

        {/* 🎄 ریسه‌های چراغ رنگارنگ */}
        <StringLights lit wires={2} bulbsPerWire={15} />

        {/* 🎈 قلب‌های شناور ظریف */}
        <div aria-hidden="true" className="absolute inset-0 z-10 overflow-hidden">
          {[
            { left: '6%', size: '1.15rem', dur: '11s', delay: '0s' },
            { left: '16%', size: '0.85rem', dur: '14s', delay: '3.5s' },
            { left: '31%', size: '1rem', dur: '12.5s', delay: '6s' },
            { left: '52%', size: '0.9rem', dur: '15s', delay: '1.8s' },
            { left: '68%', size: '1.2rem', dur: '13s', delay: '4.6s' },
            { left: '83%', size: '0.95rem', dur: '12s', delay: '2.7s' },
            { left: '93%', size: '1.05rem', dur: '16s', delay: '7.5s' },
          ].map((h, i) => (
            <span
              key={i}
              className="float-heart"
              style={
                {
                  left: h.left,
                  fontSize: h.size,
                  animationDuration: h.dur,
                  animationDelay: h.delay,
                  '--h-rot': '-8deg',
                  '--h-rot2': '12deg',
                  '--h-scale': '1',
                  '--h-scale2': '1.2',
                } as React.CSSProperties
              }
            >
              {i % 2 === 0 ? '💛' : '🤍'}
            </span>
          ))}
        </div>

        {/* ✍️ محتوای مرکزی */}
        <div className="relative z-30 mx-auto flex min-h-[100dvh] max-w-2xl flex-col items-center justify-center px-5 pb-28 pt-32 text-center sm:pb-24">
          {/* خوش‌آمد */}
          <p
            className="font-display text-[1.55rem] leading-[1.7] text-[#fff6dd] sm:text-3xl"
            style={{
              textShadow:
                '0 2px 18px rgba(0,0,0,0.55), 0 0 40px rgba(246,206,106,0.35)',
              animation: 'riseIn 1s cubic-bezier(0.22,1,0.36,1) 1.15s both',
            }}
          >
            {cfg.celebration.welcome}
          </p>

          {/* نقل‌قول */}
          <p
            className="font-quote mt-3 max-w-md text-[1.02rem] leading-[2] text-[#fbe9cf]/95 sm:text-lg"
            style={{
              textShadow: '0 1px 12px rgba(0,0,0,0.6)',
              animation: 'riseIn 1s cubic-bezier(0.22,1,0.36,1) 1.35s both',
            }}
          >
            «{cfg.celebration.quote}»
          </p>

          {/* جداکننده ظریف */}
          <div
            aria-hidden="true"
            className="mt-6 flex items-center gap-3 opacity-90"
            style={{ animation: 'riseIn 1s ease 1.5s both' }}
          >
            <span className="h-px w-14 bg-gradient-to-l from-[#f6e27a] to-transparent" />
            <span className="text-lg">💛</span>
            <span className="h-px w-14 bg-gradient-to-r from-[#f6e27a] to-transparent" />
          </div>

          {/* نام عروس و داماد — بزرگ و درخشان */}
          <h1
            className="font-nastaliq mt-2 text-[2.3rem] leading-[1.9] sm:text-6xl"
            style={{ animation: 'riseIn 1.1s cubic-bezier(0.22,1,0.36,1) 1.6s both' }}
          >
            <span className="text-gold-bright block">{cfg.groom.full}</span>
            <span
              aria-hidden="true"
              className="my-1 block text-2xl sm:text-3xl"
              style={{
                filter: 'drop-shadow(0 0 16px rgba(232,121,143,0.7))',
                animation: 'heartBeat 1.6s ease-in-out infinite',
              }}
            >
              {cfg.heart}
            </span>
            <span className="text-gold-bright block">{cfg.bride.full}</span>
          </h1>

          {/* تاریخ و مکان */}
          <div
            className="mt-6 flex flex-wrap items-center justify-center gap-2.5"
            style={{ animation: 'riseIn 1s ease 1.85s both' }}
          >
            <span className="chip-glass inline-flex items-center gap-2 rounded-full px-4 py-2 text-[0.9rem] font-bold text-[#fff3d6]">
              <span aria-hidden="true">📅</span>
              {cfg.celebration.dateLine}
            </span>
            <span className="chip-glass inline-flex items-center gap-2 rounded-full px-4 py-2 text-[0.9rem] font-bold text-[#fff3d6]">
              <span aria-hidden="true">🏛️</span>
              {cfg.celebration.venueLine}
            </span>
          </div>

          {/* دکمه‌های کاربردی */}
          <div
            className="mt-8 flex flex-wrap items-center justify-center gap-3"
            style={{ animation: 'riseIn 1s ease 2.05s both' }}
          >
            <button
              type="button"
              onClick={openNavigation}
              className="btn-action btn-action-gold"
              aria-label="باز کردن مسیر تالار در برنامه نشان"
            >
              <span aria-hidden="true">📍</span>
              {cfg.map.label}
            </button>
            <button
              type="button"
              onClick={addToCalendar}
              className="btn-action btn-action-glass"
              aria-label="افزودن تاریخ عروسی به تقویم"
            >
              <span aria-hidden="true">📅</span>
              افزودن به تقویم
            </button>
            <button
              type="button"
              onClick={handleShare}
              className="btn-action btn-action-glass"
              aria-label="اشتراک‌گذاری کارت دعوت"
            >
              <span aria-hidden="true">💌</span>
              اشتراک‌گذاری دعوت
            </button>
          </div>

          {/* نشانه اسکرول */}
          <div
            aria-hidden="true"
            className="mt-10 flex flex-col items-center gap-1 text-[#f6e27a]/80"
            style={{ animation: 'riseIn 1s ease 2.3s both' }}
          >
            <span className="text-[0.78rem] font-medium tracking-wide">
              یک قدم پایین‌تر هم ببینید
            </span>
            <span
              className="text-xl"
              style={{ animation: 'bounceSoft 1.8s ease-in-out infinite' }}
            >
              ⌄
            </span>
          </div>
        </div>
      </section>

      {/* ═══════════ بخش پایانی — نام زوج ═══════════ */}
      <section
        aria-label="پایان دعوت‌نامه"
        className="relative overflow-hidden bg-gradient-to-b from-[#fdf8ef] via-[#fbf2e2] to-[#f7ecd9] px-5 py-14 text-center"
      >
        {/* گارلند بالای بخش پایانی */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-x-0 top-0 h-44 opacity-80 sm:h-56"
          style={{
            maskImage:
              'linear-gradient(to bottom, black 15%, transparent 85%)',
            WebkitMaskImage:
              'linear-gradient(to bottom, black 15%, transparent 85%)',
          }}
        >
          <Image
            src="/images/floral-garland.png"
            alt=""
            width={1344}
            height={768}
            className="h-full w-full object-cover object-center mix-blend-multiply"
            style={{ transform: 'scale(1, -1)' }}
          />
        </div>

        <div className="relative mx-auto max-w-xl pt-40 sm:pt-48">
          <p className="font-quote text-[1.05rem] leading-[2] text-[#7a4a3a]">
            «{cfg.celebration.footerLine}»
          </p>

          <div
            aria-hidden="true"
            className="mx-auto mt-5 flex items-center justify-center gap-3"
          >
            <span className="h-px w-16 bg-gradient-to-l from-[#d4af37] to-transparent" />
            <span className="text-xl drop-shadow-[0_2px_6px_rgba(232,121,143,0.5)]">
              {cfg.heart}
            </span>
            <span className="h-px w-16 bg-gradient-to-r from-[#d4af37] to-transparent" />
          </div>

          <h2 className="font-nastaliq mt-3 text-[2rem] leading-[1.9] sm:text-5xl">
            <span className="text-gold block">{cfg.groom.full}</span>
            <span className="text-gold block">{cfg.bride.full}</span>
          </h2>

          <p className="mt-4 text-[0.92rem] font-bold tracking-wide text-[#97795a]">
            {cfg.celebration.dateLine}
            <span aria-hidden="true"> ـ </span>
            {cfg.venue.name}
          </p>

          <div
            aria-hidden="true"
            className="mt-6 flex items-center justify-center gap-2 text-lg opacity-80"
          >
            <span>🌹</span>
            <span>🤍</span>
            <span>🌹</span>
          </div>
        </div>
      </section>
    </>
  );
}
