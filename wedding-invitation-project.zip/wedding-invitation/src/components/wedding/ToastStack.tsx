'use client';

/**
 * 🍞 اعلان‌های ظریف به سبک دعوت‌نامه (کرم با حاشیه طلایی)
 */

export interface ToastItem {
  id: number;
  text: string;
}

interface ToastStackProps {
  toasts: ToastItem[];
}

export default function ToastStack({ toasts }: ToastStackProps) {
  if (toasts.length === 0) return null;
  return (
    <div className="toast-wrap" role="status" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className="toast-item">
          {t.text}
        </div>
      ))}
    </div>
  );
}
