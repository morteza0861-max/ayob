'use client';

import Image from 'next/image';
import { weddingConfig as cfg } from '@/config/wedding';

/**
 * 💳 صحنه اول — کارت دعوت عاشقانه
 * قاب کرم‌رنگ با گل‌های رز صورتی و سفید، تزئینات طلایی و تایپوگرافی فارسی.
 */

interface InvitationCardProps {
  onEnter: () => void;
}

export default function InvitationCard({ onEnter }: InvitationCardProps) {
  return (
    <section
      aria-label="کارت دعوت عروسی"
      className="relative z-10 flex min-h-[100dvh] items-center justify-center px-4 py-8 sm:py-10"
    >
      <div className="card-enter relative w-full max-w-[26.5rem]">
        {/* هاله طلایی پشت کارت */}
        <div
          aria-hidden="true"
          className="absolute -inset-6 -z-10 rounded-[3rem] opacity-70 blur-2xl"
          style={{
            background:
              'radial-gradient(60% 55% at 50% 30%, rgba(246,206,106,0.5), transparent 70%), radial-gradient(50% 45% at 30% 80%, rgba(249,200,212,0.45), transparent 70%)',
          }}
        />

        <article className="invitation-card relative overflow-hidden rounded-[1.5rem] border border-[#dcbf7f]/70 px-6 pb-0 pt-0 text-center sm:px-8">
          {/* 🌹 گارلند گل بالای کارت */}
          <div
            className="relative -mx-6 -mt-px sm:-mx-8"
            style={{
              maskImage: 'linear-gradient(to bottom, black 72%, transparent 100%)',
              WebkitMaskImage:
                'linear-gradient(to bottom, black 72%, transparent 100%)',
            }}
          >
            <Image
              src="/images/floral-garland.png"
              alt="گل‌آرایی رز صورتی و سفید با برگ‌های سبز و روبان تور"
              width={1344}
              height={768}
              priority
              className="h-auto w-full select-none mix-blend-multiply"
            />
          </div>

          {/* عنوان اصلی */}
          <p className="font-display text-gold -mt-4 text-[2rem] leading-[1.35] tracking-wide sm:text-4xl">
            {cfg.card.title}
          </p>

          {/* قاب قلبی گل */}
          <div className="relative mx-auto mt-4 w-44 sm:w-52">
            <Image
              src="/images/heart-wreath.png"
              alt="قاب قلبی از رزهای صورتی و سفید با قلب‌های طلایی"
              width={1024}
              height={1024}
              priority
              className="h-auto w-full select-none mix-blend-multiply"
              style={{
                maskImage:
                  'radial-gradient(closest-side, black 68%, transparent 98%)',
                WebkitMaskImage:
                  'radial-gradient(closest-side, black 68%, transparent 98%)',
              }}
            />
            <span
              aria-hidden="true"
              className="absolute inset-0 flex items-center justify-center pb-6 text-2xl drop-shadow-[0_2px_8px_rgba(232,121,143,0.5)]"
            >
              {cfg.heart}
            </span>
          </div>

          {/* نام عروس و داماد — دقیقاً مطابق متن: ایوب یعقوبی ❤️ غزل بارانی بیرانوند */}
          <h1 className="mt-2">
            <span className="font-nastaliq text-gold inline-block text-[1.55rem] leading-[2] sm:text-[1.85rem]">
              {cfg.groom.full}{' '}
              <span
                aria-hidden="true"
                className="align-middle text-[1.2rem] drop-shadow-[0_2px_6px_rgba(232,121,143,0.45)]"
              >
                {cfg.heart}
              </span>{' '}
              {cfg.bride.full}
            </span>
          </h1>

          {/* نقل‌قول عاشقانه */}
          <figure className="relative mx-auto mt-5 max-w-[19rem] rounded-2xl border border-[#e8b7c4]/60 bg-white/45 px-5 py-4 backdrop-blur-[2px]">
            <span
              aria-hidden="true"
              className="absolute -top-3 right-4 font-quote text-3xl text-[#c9a227]"
            >
              «
            </span>
            <blockquote className="font-quote text-[1.02rem] leading-[2] text-[#7a4a3a]">
              {cfg.card.quote}
            </blockquote>
          </figure>

          {/* متن دعوت */}
          <p className="mt-5 text-[0.98rem] font-medium leading-[1.9] text-[#5c452b]">
            {cfg.card.inviteLine}
          </p>

          {/* تاریخ */}
          <div className="mx-auto mt-4 inline-flex items-center gap-2 rounded-full border border-[#dcbf7f]/80 bg-white/55 px-5 py-2 shadow-[0_4px_14px_-6px_rgba(138,106,31,0.35)]">
            <span aria-hidden="true">📅</span>
            <time className="text-[0.95rem] font-bold tracking-wide text-[#6b4f1d]">
              {cfg.card.dateLine}
            </time>
          </div>

          {/* مکان برگزاری */}
          <div className="mx-auto mt-4 max-w-[19.5rem] rounded-2xl border border-[#dcbf7f]/60 bg-gradient-to-b from-white/50 to-[#fdf3e3]/60 px-5 py-4">
            <p className="text-[0.86rem] font-medium text-[#97795a]">
              {cfg.card.venueTitle}
            </p>
            <p className="font-display mt-1.5 text-xl leading-snug text-[#7a5a1c]">
              {cfg.venue.name}
            </p>
            <p className="mt-1 text-[0.88rem] leading-[1.9] text-[#7a5f42]">
              {cfg.venue.address}
            </p>
          </div>

          {/* شام و پذیرایی */}
          <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-gradient-to-l from-[#f9e7b8] via-[#f6e27a] to-[#f9e7b8] px-5 py-1.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.7)]">
            <span
              aria-hidden="true"
              className="text-[0.95rem] font-bold tracking-wide text-[#6b4f1d]"
            >
              {cfg.card.diningLine}
            </span>
            <span aria-hidden="true">✨</span>
          </div>

          {/* دکمه ورود به جشن */}
          <div className="relative z-10 mt-6 flex justify-center">
            <button
              type="button"
              onClick={onEnter}
              className="btn-enter rounded-full px-8 py-4 text-lg font-extrabold tracking-wide"
              aria-label={cfg.card.enterButton}
            >
              <span className="relative z-[2]">
                {cfg.card.enterButton} 💖
              </span>
            </button>
          </div>

          {/* 🌹 گارلند گل پایین کارت */}
          <div
            className="relative -mx-6 mt-7 sm:-mx-8"
            style={{
              maskImage: 'linear-gradient(to top, black 72%, transparent 100%)',
              WebkitMaskImage:
                'linear-gradient(to top, black 72%, transparent 100%)',
            }}
          >
            <Image
              src="/images/floral-garland.png"
              alt=""
              aria-hidden="true"
              width={1344}
              height={768}
              className="h-auto w-full select-none mix-blend-multiply"
              style={{ transform: 'scale(-1, -1)' }}
            />
          </div>
        </article>

        {/* راهنمای کوچک زیر کارت */}
        <p className="mt-5 text-center text-[0.8rem] font-medium text-[#a08355]">
          برای ورود به فضای جشن، روی دکمه بزنید ✨
        </p>
      </div>
    </section>
  );
}
