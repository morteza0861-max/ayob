import type { weddingConfig } from '@/config/wedding';

/**
 * 📅 ساخت و دانلود فایل تقویم (ICS) برای رویداد عروسی
 * فرمت استاندارد iCalendar است و در تقویم گوگل، iOS، اندروید و ویندوز باز می‌شود.
 */
export function downloadCalendarInvite(cfg: typeof weddingConfig): void {
  const esc = (s: string) =>
    s.replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');

  const location = `${cfg.venue.name}، ${cfg.venue.address}`;
  const stamp = new Date()
    .toISOString()
    .replace(/[-:]/g, '')
    .replace(/\.\d{3}/, '');

  const ics = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Wedding Invitation//Ayoub & Ghazal//FA',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    `UID:${Date.now()}-ayoub-ghazal@wedding`,
    `DTSTAMP:${stamp}`,
    `DTSTART:${cfg.calendar.startUTC}`,
    `DTEND:${cfg.calendar.endUTC}`,
    `SUMMARY:${esc(cfg.calendar.title)}`,
    `LOCATION:${esc(location)}`,
    `DESCRIPTION:${esc(cfg.calendar.description)}`,
    'STATUS:CONFIRMED',
    'BEGIN:VALARM',
    'TRIGGER:-P1D',
    'ACTION:DISPLAY',
    'DESCRIPTION:یادآوری جشن عروسی فردا است 💛',
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');

  const blob = new Blob([`\uFEFF${ics}`], {
    type: 'text/calendar;charset=utf-8',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = cfg.calendar.fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}
