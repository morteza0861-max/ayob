import type { weddingConfig } from '@/config/wedding';

export type ShareResult = 'shared' | 'copied' | 'dismissed' | 'failed';

/**
 * 💌 اشتراک‌گذاری لینک دعوت‌نامه
 * اول از Web Share API (مخصوص موبایل) استفاده می‌کند؛ اگر در دسترس نبود،
 * لینک را در کلیپ‌بورد کپی می‌کند.
 */
export async function shareInvite(cfg: typeof weddingConfig): Promise<ShareResult> {
  const url =
    typeof window !== 'undefined'
      ? window.location.origin + window.location.pathname
      : '/';

  // ۱) Web Share API (اندروید / iOS)
  if (typeof navigator !== 'undefined' && navigator.share) {
    try {
      await navigator.share({
        title: cfg.share.title,
        text: cfg.share.text,
        url,
      });
      return 'shared';
    } catch (err) {
      // کاربر اشتراک‌گذاری را لغو کرد
      if ((err as DOMException)?.name === 'AbortError') return 'dismissed';
      // خطای دیگر → ادامه به روش کپی
    }
  }

  // ۲) کپی لینک در کلیپ‌بورد
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(url);
      return 'copied';
    }
    throw new Error('clipboard unavailable');
  } catch {
    // ۳) روش جایگزین برای مرورگرهای قدیمی
    try {
      const ta = document.createElement('textarea');
      ta.value = url;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return ok ? 'copied' : 'failed';
    } catch {
      return 'failed';
    }
  }
}
