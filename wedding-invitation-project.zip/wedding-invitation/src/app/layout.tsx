import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "دعوت‌نامه عروسی ایوب و غزل 💛",
  description:
    "با افتخار به جشن آغاز زندگی مشترک ایوب یعقوبی و غزل بارانی بیرانوند دعوت می‌شویم — ۱۳ آبان ۱۴۰۵، تالار مجلل رویال، دورود",
  keywords: [
    "دعوت‌نامه عروسی",
    "کارت دعوت",
    "ایوب یعقوبی",
    "غزل بارانی بیرانوند",
    "تالار رویال دورود",
  ],
  icons: {
    icon: "/favicon-heart.svg",
  },
  openGraph: {
    title: "دعوت‌نامه عروسی ایوب و غزل 💛",
    description:
      "جشن آغاز زندگی مشترک — ۱۳ آبان ۱۴۰۵، تالار مجلل رویال، شهرستان دورود",
    type: "website",
    locale: "fa_IR",
  },
  twitter: {
    card: "summary_large_image",
    title: "دعوت‌نامه عروسی ایوب و غزل 💛",
    description: "۱۳ آبان ۱۴۰۵ ـ تالار مجلل رویال، شهرستان دورود",
  },
};

export const viewport: Viewport = {
  themeColor: "#fdf8ef",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground">
        {children}
      </body>
    </html>
  );
}
