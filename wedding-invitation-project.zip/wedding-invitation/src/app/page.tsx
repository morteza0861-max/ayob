'use client';

import { useCallback, useRef, useState, useSyncExternalStore } from 'react';
import { weddingConfig as cfg } from '@/config/wedding';
import InvitationCard from '@/components/wedding/InvitationCard';
import CelebrationScene from '@/components/wedding/CelebrationScene';
import CurtainTransition from '@/components/wedding/CurtainTransition';
import FallingParticles, {
  type ParticlesHandle,
} from '@/components/wedding/FallingParticles';
import MusicButton from '@/components/wedding/MusicButton';
import ToastStack, { type ToastItem } from '@/components/wedding/ToastStack';
import { useWeddingMusic } from '@/hooks/use-wedding-music';

type Phase = 'card' | 'opening' | 'celebration';

/* ♿ اشتراک ترجیح «کاهش حرکت» سیستم‌عامل (دسترس‌پذیری) */
const reducedMotionStore = {
  subscribe(onChange: () => void) {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  },
  getSnapshot() {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  },
  getServerSnapshot() {
    return false;
  },
};

/**
 * 💛 تجربه کامل دعوت‌نامه دیجیتال عروسی
 *
 * ▸ صحنه ۱: کارت دعوت عاشقانه
 * ▸ ترنزیشن سینمایی: باز شدن پرده‌های گل‌آرایی‌شده + موسیقی
 * ▸ صحنه ۲: فضای جشن با چراغونی، ریسه‌های رنگارنگ و ذرات طلایی
 *
 * عنصر موسیقی در همین کامپوننت ریشه رندر می‌شود؛ بنابراین با جابه‌جایی
 * بین بخش‌های صفحه هرگز قطع نمی‌شود.
 */
export default function WeddingExperience() {
  const [phase, setPhase] = useState<Phase>('card');
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const reduced = useSyncExternalStore(
    reducedMotionStore.subscribe,
    reducedMotionStore.getSnapshot,
    reducedMotionStore.getServerSnapshot
  );
  const toastIdRef = useRef(0);
  const particlesRef = useRef<ParticlesHandle | null>(null);

  const music = useWeddingMusic();

  const showToast = useCallback((text: string) => {
    const id = ++toastIdRef.current;
    setToasts((prev) => [...prev.slice(-2), { id, text }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4200);
  }, []);

  /* 🎬 ورود به جشن — کلیک کاربر: موسیقی + پرده سینمایی */
  const handleEnter = useCallback(() => {
    if (phase !== 'card') return;
    music.start(); // باید بلافاصله در هندلر کلیک اجرا شود (سیاست مرورگرها)
    setPhase('opening');
    if (typeof window !== 'undefined') window.scrollTo(0, 0);

    // پس از باز شدن پرده‌ها، صحنه جشن کاملاً جایگزین می‌شود
    window.setTimeout(() => {
      setPhase('celebration');
      showToast('💛 به جشن عشق ایوب و غزل خوش آمدید!');
    }, reduced ? 1200 : 2750);
  }, [phase, music, showToast, reduced]);

  /* نمایش دکمه موسیقی: از لحظه ورود به جشن */
  const musicVisible = phase !== 'card';

  return (
    <main
      className={`relative min-h-[100dvh] overflow-x-clip ${
        music.isPlaying ? 'music-playing' : ''
      }`}
      style={{
        background:
          phase === 'card'
            ? 'linear-gradient(180deg, #fdf8ef 0%, #fbf3e4 45%, #f7ecd9 100%)'
            : undefined,
      }}
    >
      {/* 🌹 پس‌زمینه کرم با هاله‌های ظریف برای صحنه کارت */}
      {phase === 'card' && (
        <div
          aria-hidden="true"
          className="pointer-events-none fixed inset-0 z-0"
          style={{
            background:
              'radial-gradient(46% 32% at 18% 12%, rgba(249,200,212,0.4), transparent 70%), radial-gradient(42% 30% at 84% 20%, rgba(246,206,106,0.35), transparent 70%), radial-gradient(50% 38% at 78% 86%, rgba(249,200,212,0.32), transparent 70%), radial-gradient(40% 30% at 14% 82%, rgba(127,168,127,0.16), transparent 70%)',
          }}
        />
      )}

      {/* ✨ ذرات شناور: گلبرگ رز، قلب طلایی و ذرات نورانی */}
      <FallingParticles ref={particlesRef} mode={phase === 'card' ? 'card' : 'celebration'} reduced={reduced} />

      {/* 💳 صحنه ۱: کارت دعوت */}
      {phase === 'card' && <InvitationCard onEnter={handleEnter} />}

      {/* 🎊 صحنه ۲: جشن (همراه با فوتر پایانی) */}
      {(phase === 'opening' || phase === 'celebration') && (
        <CelebrationScene particlesRef={particlesRef} showToast={showToast} />
      )}

      {/* 🎬 ترنزیشن پرده سینمایی */}
      {phase === 'opening' && <CurtainTransition />}

      {/* 🎛️ دکمه موسیقی همیشه در دسترس */}
      <MusicButton
        isPlaying={music.isPlaying}
        isLoading={music.isLoading}
        error={music.error}
        visible={musicVisible}
        onToggle={music.toggle}
        onRetry={() => {
          music.retry();
          showToast('🎵 در حال تلاش مجدد برای پخش موسیقی...');
        }}
      />

      {/* هشدار خطای موسیقی */}
      {music.error && musicVisible && (
        <div className="toast-wrap" style={{ bottom: 'calc(10.5rem + env(safe-area-inset-bottom, 0px))' }}>
          <div className="toast-item flex items-center justify-between gap-3">
            <span>⚠️ موسیقی بارگذاری نشد؛ دوباره تلاش کنید.</span>
            <button
              type="button"
              onClick={music.retry}
              className="shrink-0 rounded-full bg-gradient-to-l from-[#e9c25c] to-[#c9a227] px-3 py-1 text-[0.78rem] font-extrabold text-[#4c360c]"
            >
              تلاش مجدد
            </button>
          </div>
        </div>
      )}

      <ToastStack toasts={toasts} />
    </main>
  );
}
